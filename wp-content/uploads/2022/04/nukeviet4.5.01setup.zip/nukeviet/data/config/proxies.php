<?php

/**
 * @Project NUKEVIET 4.x
 * @Author VINADES.,JSC (contact@vinades.vn)
 * @Copyright (C) 2014 VINADES.,JSC. All rights reserved
 * @License GNU/GPL version 2 or any later version
 * @Createdate 20/9/2011, 13:3
 */

/**
 * $proxy[] = array('HTTP','222.220.229.194',8909,'login','pass');
 * trong do, gia tri 0 la protocol (co the la HTTP, SOCKS4, SOCKS5): bat buoc
 * gia tri 1 la IP: bat buoc
 * gia tri 2 la PORT: bat buoc
 * gia tri 3 la tai khoan: khong bat buoc
 * gia tri 4 la mat khau: khong bat buoc
 */
$proxy = array();
//$proxy[] = array('HTTP','222.220.229.194',8909,'login','pass');
