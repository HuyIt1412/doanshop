<?php

/**
 * @Project NUKEVIET 4.x
 * @This product includes GeoLite2 data created by MaxMind, available from http://www.maxmind.com
 * @Createdate Wed, 18 Apr 2018 03:19:55 GMT
 */

$ranges=array(352321536=>array(353769239,'US'),353769240=>array(353769240,'FR'),353769241=>array(358157194,'US'),358157195=>array(358157195,'NO'),358157196=>array(369098751,'US'));
