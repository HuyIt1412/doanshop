﻿Hướng dẫn cài đặt NukeViet 4.5.01:

1. Giải nén file tải về.
2. Upload toàn bộ các file và thư mục con trong thư mục "nukeviet" lên vị trí thích hợp trên máy chủ (hosting):
    - Nếu bạn muốn cài đặt NukeViet tại thư mục gốc của website (ví dụ http://example.com/), upload toàn bộ các file và thư mục con trong thư mục "nukeviet" đã giải nén vào thư mục gốc trên máy chủ (hosting) của bạn.
    - Nếu bạn muốn cài đặt NukeViet trong thư mục con trên website (ví dụ http://example.com/subdir/), hãy tạo thư mục con trên máy chủ (hosting) và upload toàn bộ các file và thư mục con trong thư mục "nukeviet" đã giải nén vào thư mục con đã tạo.
3. Truy cập website bằng trình duyệt internet để cài đặt:
    - Nếu bạn cài đặt NukeViet trong thư mục gốc, bạn truy cập: http://example.com/
    - Nếu bạn cài đặt NukeViet trong thư mục con ví dụ subdir, bạn truy cập: http://example.com/subdir/

Yêu cầu cài đặt:
- Hệ điều hành:  Unix (Linux, Ubuntu, Fedora...) hoặc Windows
- PHP: PHP từ phiên bản 5.6 đến phiên bản PHP 8.2
- MySQL: MySQL >= 5.5
Xem thêm tại: https://wiki.nukeviet.vn/nukeviet4:setup:requirements

Mọi thắc mắc và yêu cầu trợ giúp vui lòng truy cập website: https://nukeviet.vn 
hoặc tham gia diễn đàn https://forum.nukeviet.vn
     gia nhập nhóm facebook: http://fb.com/groups/nukeviet/
